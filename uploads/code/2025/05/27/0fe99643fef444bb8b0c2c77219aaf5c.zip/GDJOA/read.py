import pandas as pd

# 文件路径
logistics_path = "2025.4.30后勤表.xlsx"
smart_engineering_path = "4月智慧工程.xlsx"
work_plan_path = "导出工作计划.xls"

# 读取前几行
logistics_df = pd.read_excel(logistics_path, nrows=10)
smart_engineering_df = pd.read_excel(smart_engineering_path, nrows=300)
work_plan_df = pd.read_excel(work_plan_path, nrows=10, engine='xlrd')

print("后勤表字段：", logistics_df.columns.tolist())
print(logistics_df)
print("\n智慧工程表字段：", smart_engineering_df.columns.tolist())
print(smart_engineering_df)
print("\n导出工作计划表字段：", work_plan_df.columns.tolist())
print(work_plan_df)