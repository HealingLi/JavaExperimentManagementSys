import pandas as pd

# 1. 读取后勤表（不跳过表头）
logistics_path = "2025.4.30后勤表.xlsx"
logistics_df = pd.read_excel(logistics_path)

# 2. 读取智慧工程表
smart_engineering_path = "4月智慧工程.xlsx"
smart_df = pd.read_excel(smart_engineering_path)

# 3. 读取导出工作计划表
work_plan_path = "导出工作计划.xls"
work_plan_df = pd.read_excel(work_plan_path, engine='xlrd')

def warn_unmatched_personnel(smart_df):
    unmatched = smart_df[smart_df['项目部'].isna()]
    if not unmatched.empty:
        print("【警告】以下监理人员姓名在后勤表找不到对应项目部（不参与统计）：")
        print(unmatched['监理人员姓名'].drop_duplicates().tolist())
        print(f"共{len(unmatched)}条记录未匹配到项目部。")
    else:
        print("所有监理人员均已匹配到项目部。")

# 4. 用后勤表"姓名"匹配智慧工程表"监理人员姓名"，补充"项目部"列
def add_project_department(smart_df, logistics_df):
    # logistics_df: 姓名、所属部门
    mapping = logistics_df.set_index('姓名')['所属部门']
    smart_df['项目部'] = smart_df['监理人员姓名'].map(mapping)
    warn_unmatched_personnel(smart_df)
    return smart_df[~smart_df['项目部'].isna()]  # 只保留已匹配的

smart_df = add_project_department(smart_df, logistics_df)

# 5. 统计函数（通用）
def calc_stats(df, dept_col, plan_col, risk_col, attend_col, high_risk_list, low_risk_list):
    # 到位判断：考勤/签到>0或空白算到位
    df['是否到位'] = df[attend_col].apply(lambda x: 1 if (pd.isna(x) or (isinstance(x, (int, float)) and x > 0)) else 0)
    # 中高风险
    high = df[df[risk_col].isin(high_risk_list)]
    high_stats = high.groupby(dept_col).agg(计划数=(plan_col, 'count'), 到位数=('是否到位', 'sum'))
    high_stats['到位率'] = high_stats['到位数'] / high_stats['计划数']
    # 低/可接受风险
    low = df[df[risk_col].isin(low_risk_list)]
    low_stats = low.groupby(dept_col).agg(计划数=(plan_col, 'count'), 到位数=('是否到位', 'sum'))
    low_stats['到位率'] = low_stats['到位数'] / low_stats['计划数']
    return high_stats, low_stats

# 检查风险等级和监理考勤人数
print("风险等级分布：")
print(smart_df['风险等级'].value_counts(dropna=False))
print("监理考勤人数样例：")
print(smart_df['监理考勤人数'].head(10))

# 6. 智慧工程表统计
print(smart_df[['项目部', '项目名称', '风险等级', '监理考勤人数']].head(20))
smart_high, smart_low = calc_stats(
    smart_df,
    dept_col='项目部',
    plan_col='项目名称',
    risk_col='风险等级',
    attend_col='监理考勤人数',
    high_risk_list=['中', '高'],
    low_risk_list=['低', '可接受']
)

# 7. 导出工作计划表统计
work_high, work_low = calc_stats(
    work_plan_df,
    dept_col='所属部门',
    plan_col='计划项目',
    risk_col='风险等级',
    attend_col='签到次数',
    high_risk_list=['中风险', '高风险'],
    low_risk_list=['低风险', '可接受风险']
)

# 8. 导出结果
smart_high.to_excel('智慧工程_中高风险到位率统计.xlsx')
smart_low.to_excel('智慧工程_低风险到位率统计.xlsx')
work_high.to_excel('工作计划_中高风险到位率统计.xlsx')
work_low.to_excel('工作计划_低风险到位率统计.xlsx')

print("统计完成，已导出四张表。")

print(smart_df[['监理人员姓名', '项目部']].head(20))
print(smart_df['项目部'].isna().sum(), '/', len(smart_df))

print(smart_df['风险等级'].value_counts(dropna=False))
print(smart_df['监理考勤人数'].head(20)) 