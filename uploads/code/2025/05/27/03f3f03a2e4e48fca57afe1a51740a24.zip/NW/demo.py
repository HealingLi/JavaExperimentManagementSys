import pandas as pd
import os

def read_names_from_file(filename):
    ext = os.path.splitext(filename)[1].lower()
    names = []
    if ext == '.txt':
        with open(filename, 'r', encoding='utf-8') as f:
            names = [line.strip() for line in f if line.strip()]
    elif ext == '.docx':
        from docx import Document
        doc = Document(filename)
        names = [para.text.strip() for para in doc.paragraphs if para.text.strip()]
    else:
        raise ValueError("只支持txt或docx文件")
    return names

def stat_supervision_count_for_projects(names_file, excel_files):
    # 1. 读取名字
    try:
        names = read_names_from_file(names_file)
    except Exception as e:
        print(f'读取名字文件失败: {e}')
        return

    # 2. 合并所有表
    df_list = []
    for excel_file in excel_files:
        try:
            df = pd.read_excel(excel_file)
            df_list.append(df)
        except Exception as e:
            print(f"读取{excel_file}失败: {e}")
    if not df_list:
        print("没有可用的Excel数据")
        return
    df_all = pd.concat(df_list, ignore_index=True)

    # 3. 只保留名单内的记录
    df_selected = df_all[df_all['姓名'].isin(names)].copy()

    # 4. 提取城市
    def extract_city(s):
        if pd.isna(s):
            return None
        parts = str(s).split('\\')
        if len(parts) > 3:
            return parts[3].replace('供电局', '').strip()
        return None
    df_selected['城市'] = df_selected['所属业主项目部'].apply(extract_city)

    # 5. 统计每个城市的唯一作业计划编号数量
    city_code_count = df_selected.groupby('城市')['作业计划编号'].nunique()

    # 6. 读取第三方督查计划管控【空白】.xlsx
    try:
        all_sheets = pd.read_excel('第三方督查计划管控【空白】.xlsx', sheet_name=None)
        for sheet_name, df in all_sheets.items():
            if '项目部' in df.columns:
                df_plan = df.copy()
                print(f'已自动选中含"项目部"列的sheet: {sheet_name}')
                break
        else:
            print('所有sheet中均未找到"项目部"列，请检查表格内容！')
            return
    except Exception as e:
        print(f"读取第三方督查计划管控【空白】.xlsx失败: {e}")
        return

    df_plan['督查次数'] = df_plan['项目部'].apply(lambda x: city_code_count.get(str(x).strip(), 0))

    try:
        df_plan.to_excel('第三方督查计划管控【已填写】.xlsx', index=False)
        print('统计并写入完成，结果已保存为"第三方督查计划管控【已填写】.xlsx"')
    except Exception as e:
        print(f"保存结果失败: {e}")

if __name__ == "__main__":
    if os.path.exists('人员名单.docx'):
        names_file = '人员名单.docx'
    elif os.path.exists('人员名单.txt'):
        names_file = '人员名单.txt'
    else:
        print('未找到人员名单.docx或人员名单.txt')
        exit(1)
    excel_files = ['阳江局出勤导出.xlsx', '阳江局周计划导出.xlsx']
    stat_supervision_count_for_projects(names_file, excel_files)
