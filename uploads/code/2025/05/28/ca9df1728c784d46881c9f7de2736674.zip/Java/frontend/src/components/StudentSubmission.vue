<template>
  <div class="student-submission">
    <h2>学生作业提交</h2>
    <form @submit.prevent="submitAssignment">
      <input v-model="assignmentId" type="number" placeholder="作业 ID" required />
      <input v-model="codeFilePath" type="text" placeholder="代码文件路径" required />
      <input v-model="resultImagePath" type="text" placeholder="结果图片路径" />
      <button type="submit">提交作业</button>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import axios from 'axios';

const assignmentId = ref('');
const codeFilePath = ref('');
const resultImagePath = ref('');

const submitAssignment = async () => {
  try {
    await axios.post('/api/submissions', {
      assignmentId: assignmentId.value,
      codeFilePath: codeFilePath.value,
      resultImagePath: resultImagePath.value,
    });
    alert('作业提交成功');
  } catch (error) {
    console.error('作业提交失败', error);
    alert('作业提交失败，请重试');
  }
};
</script>

<style scoped>
.student-submission {
  max-width: 500px;
  margin: 0 auto;
  padding: 20px;
}

form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
</style>