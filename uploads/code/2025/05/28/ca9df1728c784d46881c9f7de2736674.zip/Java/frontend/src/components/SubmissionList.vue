<template>
  <div class="submission-list">
    <h2>作业提交列表</h2>
    <div v-if="loading" class="loading">加载中...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else>
      <table>
        <thead>
          <tr>
            <th>学生ID</th>
            <th>提交时间</th>
            <th>代码路径</th>
            <th>结果图片</th>
            <th>分数</th>
            <th>反馈</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="submission in submissions" :key="submission.id">
            <td>{{ submission.studentId }}</td>
            <td>{{ submission.submittedAt }}</td>
            <td>{{ submission.codeFilePath }}</td>
            <td><a :href="submission.resultImagePath" target="_blank">查看图片</a></td>
            <td>{{ submission.score || '未批改' }}</td>
            <td>{{ submission.feedback || '-' }}</td>
            <td>
              <button @click="openGradingForm(submission.id)">批改</button>
            </td>
          </tr>
        </tbody>
      </table>
      <div v-if="statistics" class="statistics">
        <h3>分数统计</h3>
        <p>{{ statistics }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import GradingForm from './GradingForm.vue';
export default {
  components: { GradingForm },
  data() {
    return {
      submissions: [],
      loading: false,
      error: null,
      statistics: '',
      showGradingForm: false,
      currentSubmissionId: null
    };
  },
  props: {
    assignmentId: {
      type: Number,
      required: true
    }
  },
  async mounted() {
    await this.fetchSubmissions();
  },
  methods: {
    async fetchSubmissions() {
      this.loading = true;
      this.error = null;
      try {
        const [submissionsRes, statisticsRes] = await Promise.all([
          axios.get(`/api/assignments/${this.assignmentId}/submissions`),
          axios.get(`/grading/assignment/${this.assignmentId}/statistics`)
        ]);
        this.submissions = submissionsRes.data;
        this.statistics = statisticsRes.data;
      } catch (err) {
        this.error = err.response?.data?.message || '获取数据失败';
      } finally {
        this.loading = false;
      }
    },
    openGradingForm(submissionId) {
      this.currentSubmissionId = submissionId;
      this.showGradingForm = true;
    },
    onGradingSuccess() {
      this.showGradingForm = false;
      this.fetchSubmissions();
    }
  }
};
</script>

<style scoped>
.submission-list {
  padding: 20px;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 15px;
}
table th, table td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}
table tr:nth-child(even) {
  background-color: #f2f2f2;
}
.loading, .error {
  padding: 10px;
  text-align: center;
}
.statistics {
  margin-top: 20px;
  padding: 10px;
  background-color: #f8f9fa;
}
</style>