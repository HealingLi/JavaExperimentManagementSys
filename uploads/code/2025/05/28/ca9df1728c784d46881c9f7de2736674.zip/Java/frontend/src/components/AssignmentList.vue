<template>
  <div class="assignment-list">
    <h2>题目列表</h2>
    <ul>
      <li v-for="assignment in assignments" :key="assignment.id">
        <h3>{{ assignment.title }}</h3>
        <p>{{ assignment.description }}</p>
        <p>截止日期: {{ formatDate(assignment.deadline) }}</p>
        <button @click="submitAssignment(assignment.id)">提交作业</button>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const assignments = ref([]);

const fetchAssignments = async () => {
  try {
// 假设后端 API 地址为 /api/assignments，使用 fetch 进行 API 调用
const response = await fetch('/api/assignments');
if (response.ok) {
  assignments.value = await response.json();
} else {
  throw new Error('获取题目列表失败');
}
    // 示例数据
    assignments.value = [
      {
        id: 1,
        title: 'Java 基础作业',
        description: '完成 Java 基础练习',
        deadline: new Date('2024-12-31'),
      },
      {
        id: 2,
        title: '数据库作业',
        description: '设计数据库表结构',
        deadline: new Date('2024-11-30'),
      },
    ];
  } catch (error) {
    console.error('获取题目列表失败:', error);
  }
};

const formatDate = (date) => {
  return new Date(date).toLocaleDateString();
};

const submitAssignment = (assignmentId) => {
  // 这里应替换为实际的提交作业 API 调用
  console.log('提交作业:', assignmentId);
};

onMounted(() => {
  fetchAssignments();
});
</script>

<style scoped>
.assignment-list {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 15px;
  margin-bottom: 10px;
}
button {
  padding: 8px 15px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}
button:hover {
  background-color: #0056b3;
}
</style>