<template>
  <div class="student-home">
    <h2>Student Dashboard</h2>
    <p>Welcome to the student assignment interface!</p>
  </div>
</template>

<script setup>
// Student home page logic can be added here later
</script>

<style scoped>
.student-home {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}
</style>