<template>
  <div class="teacher-grading">
    <h2>教师作业批改</h2>
    <table>
      <thead>
        <tr>
          <th>提交 ID</th>
          <th>学生用户名</th>
          <th>作业标题</th>
          <th>分数</th>
          <th>反馈</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="submission in submissions" :key="submission.id">
          <td>{{ submission.id }}</td>
          <td>{{ submission.student.username }}</td>
          <td>{{ submission.assignment.title }}</td>
          <td><input v-model="submission.score" type="number" /></td>
          <td><textarea v-model="submission.feedback"></textarea></td>
          <td><button @click="submitGrade(submission)">提交批改</button></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

const submissions = ref([]);

onMounted(async () => {
  try {
    const response = await axios.get('/api/submissions');
    submissions.value = response.data;
  } catch (error) {
    console.error('获取作业提交列表失败', error);
  }
});

const submitGrade = async (submission) => {
  try {
    await axios.post(`/grading/${submission.id}/grade`, {
      score: submission.score,
      feedback: submission.feedback
    });
    alert('批改提交成功');
  } catch (error) {
    console.error('批改提交失败', error);
    alert('批改提交失败，请重试');
  }
};
</script>

<style scoped>
.teacher-grading {
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}
</style>