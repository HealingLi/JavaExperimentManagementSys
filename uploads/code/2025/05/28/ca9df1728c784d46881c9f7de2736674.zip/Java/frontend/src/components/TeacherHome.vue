<template>
  <div class="teacher-home">
    <h2>Teacher Dashboard</h2>
    <p>Welcome to the teacher grading interface!</p>
  </div>
</template>

<script setup>
// Teacher home page logic can be added here later
</script>

<style scoped>
.teacher-home {
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
}
</style>