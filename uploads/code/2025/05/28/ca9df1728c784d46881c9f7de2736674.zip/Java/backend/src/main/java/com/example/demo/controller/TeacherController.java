package com.example.demo.controller;

import com.example.demo.entity.Teacher;
import com.example.demo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/teachers")
@Validated
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @PostMapping("/register")
    public ResponseEntity<String> registerTeacher(@Valid @RequestBody Teacher teacher) {
        if (teacherService.save(teacher)) {
            return new ResponseEntity<>("Teacher registered successfully", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Failed to register teacher", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Teacher> loginTeacher(@RequestParam String email, @RequestParam String password) {
        Teacher teacher = teacherService.login(email, password);
        if (teacher != null) {
            return new ResponseEntity<>(teacher, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Teacher> getTeacherById(@PathVariable Long id) {
        Teacher teacher = teacherService.getById(id);
        if (teacher == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(teacher, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateTeacher(@PathVariable Long id, @Valid @RequestBody Teacher teacher) {
        teacher.setId(id);
        if (teacherService.updateById(teacher)) {
            return new ResponseEntity<>("Teacher updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to update teacher", HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTeacher(@PathVariable Long id) {
        if (teacherService.removeById(id)) {
            return new ResponseEntity<>("Teacher deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to delete teacher", HttpStatus.BAD_REQUEST);
        }
    }
}