-- 用户表（区分教师/学生）
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('TEACHER', 'STUDENT') NOT NULL,
    created_at DATETIME DEFAULT NOW()
);

-- 题目表
CREATE TABLE assignments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    teacher_id INT NOT NULL,
    deadline DATETIME,
    FOREIGN KEY (teacher_id) REFERENCES users(id)
);

-- 提交记录表
CREATE TABLE submissions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    assignment_id INT NOT NULL,
    code_file_path VARCHAR(255) NOT NULL,
    result_image_path VARCHAR(255),
    score INT,
    feedback TEXT,
    submitted_at DATETIME DEFAULT NOW(),
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (assignment_id) REFERENCES assignments(id)
);