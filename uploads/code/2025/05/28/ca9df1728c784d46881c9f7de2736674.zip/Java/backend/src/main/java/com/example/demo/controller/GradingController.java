package com.example.demo.controller;

import com.example.demo.dto.SubmissionDTO;
import com.example.demo.entity.Submission;
import com.example.demo.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/grading")
public class GradingController {

    @Autowired
    private SubmissionService submissionService;

    @GetMapping("/submissions/{id}")
    public ResponseEntity<Submission> getSubmissionById(@PathVariable Long id) {
        Submission submission = submissionService.getById(id);
        if (submission == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(submission, HttpStatus.OK);
    }

    @PutMapping("/submissions/{id}/grade")
    public ResponseEntity<String> gradeSubmission(@PathVariable Long id, @RequestBody SubmissionDTO submissionDTO) {
        Submission submission = submissionService.getById(id);
        if (submission == null) {
            return new ResponseEntity<>("Submission not found", HttpStatus.NOT_FOUND);
        }
        submission.setResultImage(submissionDTO.getResultImage()); // Assuming resultImage is used for grading results
        submissionService.updateById(submission);
        return new ResponseEntity<>("Graded successfully", HttpStatus.OK);
    }
}