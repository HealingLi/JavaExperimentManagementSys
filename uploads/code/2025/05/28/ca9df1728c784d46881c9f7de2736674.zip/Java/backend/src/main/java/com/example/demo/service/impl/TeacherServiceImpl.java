package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.entity.Teacher;
import com.example.demo.Mapper.TeacherMapper;
import com.example.demo.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl extends ServiceImpl<TeacherMapper, Teacher> implements TeacherService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public boolean save(Teacher teacher) {
        teacher.setPassword(passwordEncoder.encode(teacher.getPassword()));
        return super.save(teacher);
    }

    public Teacher login(String email, String password) {
        QueryWrapper<Teacher> wrapper = new QueryWrapper<>();
        wrapper.eq("email", email);
        Teacher teacher = getOne(wrapper);
        if (teacher != null && passwordEncoder.matches(password, teacher.getPassword())) {
            return teacher;
        }
        return null;
    }
}