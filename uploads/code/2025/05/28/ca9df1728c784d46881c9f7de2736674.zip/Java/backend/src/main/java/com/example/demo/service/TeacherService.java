package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.entity.Teacher;

public interface TeacherService extends IService<Teacher> {
    Teacher login(String email, String password);
}