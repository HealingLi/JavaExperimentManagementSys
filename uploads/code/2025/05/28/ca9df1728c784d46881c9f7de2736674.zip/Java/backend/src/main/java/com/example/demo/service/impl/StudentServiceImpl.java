package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.entity.Student;
import com.example.demo.Mapper.StudentMapper;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student> implements StudentService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public boolean save(Student student) {
        student.setPassword(passwordEncoder.encode(student.getPassword()));
        return super.save(student);
    }

    public Student login(String email, String password) {
        QueryWrapper<Student> wrapper = new QueryWrapper<>();
        wrapper.eq("email", email);
        Student student = getOne(wrapper);
        if (student != null && passwordEncoder.matches(password, student.getPassword())) {
            return student;
        }
        return null;
    }
}