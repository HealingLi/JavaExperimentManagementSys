//package com.example.demo.controller;
//
//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//import com.example.demo.entity.Experiment;
//import com.example.demo.service.ExperimentService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/experiment")
//public class ExperimentController {
//
//    @Autowired
//    private ExperimentService experimentService;
//
//    // 教师添加实验题目
//    @PostMapping("/add")
//    public ResponseEntity<String> addExperiment(@RequestBody Experiment experiment) {
//        boolean save = experimentService.save(experiment);
//        return save ? ResponseEntity.ok("题目添加成功") : ResponseEntity.badRequest().body("题目添加失败");
//    }
//
//    // 教师修改实验题目
//    @PutMapping("/update")
//    public ResponseEntity<String> updateExperiment(@RequestBody Experiment experiment) {
//        boolean update = experimentService.updateById(experiment);
//        return update ? ResponseEntity.ok("题目修改成功") : ResponseEntity.badRequest().body("题目修改失败");
//    }
//
//    // 教师删除实验题目
//    @DeleteMapping("/delete/{id}")
//    public ResponseEntity<String> deleteExperiment(@PathVariable Long id) {
//        boolean remove = experimentService.removeById(id);
//        return remove ? ResponseEntity.ok("题目删除成功") : ResponseEntity.badRequest().body("题目删除失败");
//    }
//
//    // 查询所有实验题目（教师/学生端通用）
//    @GetMapping("/list")
//    public ResponseEntity<List<Experiment>> listExperiments() {
//        List<Experiment> list = experimentService.list(new QueryWrapper<>());
//        return ResponseEntity.ok(list);
//    }
//}