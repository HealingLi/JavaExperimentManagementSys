//package com.example.demo.entity;
//
//import com.baomidou.mybatisplus.annotation.IdType;
//import com.baomidou.mybatisplus.annotation.TableId;
//import com.baomidou.mybatisplus.annotation.TableName;
//import jakarta.validation.constraints.NotBlank;
//import lombok.Data;
//
//@Data
//@TableName("experiment")
//public class Experiment {
//    @TableId(type = IdType.AUTO)
//    private Long id;
//
//    @NotBlank(message = "Experiment name is mandatory")
//    private String name;
//
//    private String description;
//
//    private String deadline;
//
//    // Getter和Setter方法
//    public Long getId() { return id; }
//    public void setId(Long id) { this.id = id; }
//    public String getName() { return name; }
//    public void setName(String name) { this.name = name; }
//    public String getDescription() { return description; }
//    public void setDescription(String description) { this.description = description; }
//    public String getDeadline() { return deadline; }
//    public void setDeadline(String deadline) { this.deadline = deadline; }
//
//    // 无参构造
//    public Experiment() {}
//
//    // 全参构造
//    public Experiment(Long id, String name, String description, String deadline) {
//        this.id = id;
//        this.name = name;
//        this.description = description;
//        this.deadline = deadline;
//    }
//}