package com.example.demo.controller;

import com.example.demo.dto.SubmissionDTO;
import com.example.demo.entity.Submission;
import com.example.demo.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/submissions")
@Validated
public class SubmissionController {

    @Autowired
    private SubmissionService submissionService;

    @PostMapping("/")
    public ResponseEntity<String> submitCode(@Valid @RequestBody SubmissionDTO submissionDTO) {
        Submission submission = new Submission();
        submission.setStudentId(submissionDTO.getStudentId());
        submission.setQuestionId(submissionDTO.getQuestionId());
        submission.setCode(submissionDTO.getCode());

        if (submissionService.save(submission)) {
            return new ResponseEntity<>("Submission added successfully", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("Failed to add submission", HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<Submission>> getAllSubmissions() {
        List<Submission> submissions = submissionService.list();
        return new ResponseEntity<>(submissions, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Submission> getSubmissionById(@PathVariable Long id) {
        Submission submission = submissionService.getById(id);
        if (submission == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(submission, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> updateSubmission(@PathVariable Long id, @Valid @RequestBody SubmissionDTO submissionDTO) {
        Submission submission = submissionService.getById(id);
        if (submission == null) {
            return new ResponseEntity<>("Submission not found", HttpStatus.NOT_FOUND);
        }
        submission.setCode(submissionDTO.getCode());
        submission.setResultImage(submissionDTO.getResultImage());

        if (submissionService.updateById(submission)) {
            return new ResponseEntity<>("Submission updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to update submission", HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSubmission(@PathVariable Long id) {
        if (submissionService.removeById(id)) {
            return new ResponseEntity<>("Submission deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to delete submission", HttpStatus.BAD_REQUEST);
        }
    }
}



