//package com.example.demo.Mapper;
//
//import com.baomidou.mybatisplus.core.mapper.BaseMapper;
//import com.example.demo.entity.Experiment;
//import org.apache.ibatis.annotations.Mapper;
//
//@Mapper
//public interface ExperimentMapper extends BaseMapper<Experiment> {
//}