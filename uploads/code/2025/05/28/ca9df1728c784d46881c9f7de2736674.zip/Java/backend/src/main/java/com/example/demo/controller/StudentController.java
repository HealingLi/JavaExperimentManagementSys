package com.example.demo.controller;

import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/students")
@Validated
public class StudentController {

  @Autowired
  private StudentService studentService;

  @PostMapping("/register")
  public ResponseEntity<String> registerStudent(@Valid @RequestBody Student student) {
    if (studentService.save(student)) {
      return new ResponseEntity<>("Student registered successfully", HttpStatus.CREATED);
    } else {
      return new ResponseEntity<>("Failed to register student", HttpStatus.BAD_REQUEST);
    }
  }

  @PostMapping("/login")
  public ResponseEntity<Student> loginStudent(@RequestParam String email, @RequestParam String password) {
    Student student = studentService.login(email, password);
    if (student != null) {
      return new ResponseEntity<>(student, HttpStatus.OK);
    } else {
      return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }
  }

  @GetMapping("/{id}")
  public ResponseEntity<Student> getStudentById(@PathVariable Long id) {
    Student student = studentService.getById(id);
    if (student == null) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    return new ResponseEntity<>(student, HttpStatus.OK);
  }

  @PutMapping("/{id}")
  public ResponseEntity<String> updateStudent(@PathVariable Long id, @Valid @RequestBody Student student) {
    student.setId(id);
    if (studentService.updateById(student)) {
      return new ResponseEntity<>("Student updated successfully", HttpStatus.OK);
    } else {
      return new ResponseEntity<>("Failed to update student", HttpStatus.BAD_REQUEST);
    }
  }

  @DeleteMapping("/{id}")
  public ResponseEntity<String> deleteStudent(@PathVariable Long id) {
    if (studentService.removeById(id)) {
      return new ResponseEntity<>("Student deleted successfully", HttpStatus.OK);
    } else {
      return new ResponseEntity<>("Failed to delete student", HttpStatus.BAD_REQUEST);
    }
  }
}